﻿namespace Airline_Management_System
{
    partial class AddPassenger
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddPassenger));
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties11 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties12 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties13 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties14 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties15 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties16 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties17 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties18 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties19 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties20 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            label2 = new Label();
            label1 = new Label();
            label3 = new Label();
            PassId = new Bunifu.UI.WinForms.BunifuTextBox();
            label4 = new Label();
            PassName = new Bunifu.UI.WinForms.BunifuTextBox();
            label5 = new Label();
            PassportTb = new Bunifu.UI.WinForms.BunifuTextBox();
            label6 = new Label();
            PassAd = new Bunifu.UI.WinForms.BunifuTextBox();
            NationalityCb = new ComboBox();
            label7 = new Label();
            GenderCb = new ComboBox();
            label8 = new Label();
            label9 = new Label();
            PhoneTb = new Bunifu.UI.WinForms.BunifuTextBox();
            button2 = new Button();
            button1 = new Button();
            label10 = new Label();
            pictureBox1 = new PictureBox();
            panel1 = new Panel();
            button3 = new Button();
            button4 = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Century Gothic", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Red;
            label2.Location = new Point(187, 77);
            label2.Name = "label2";
            label2.Size = new Size(270, 34);
            label2.TabIndex = 5;
            label2.Text = "Record Passengers";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Red;
            label1.Location = new Point(152, 43);
            label1.Name = "label1";
            label1.Size = new Size(372, 34);
            label1.TabIndex = 4;
            label1.Text = "Biman Bangladesh Airlines";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Navy;
            label3.Location = new Point(12, 153);
            label3.Name = "label3";
            label3.Size = new Size(134, 23);
            label3.TabIndex = 11;
            label3.Text = "Passenger Id";
            // 
            // PassId
            // 
            PassId.AcceptsReturn = false;
            PassId.AcceptsTab = false;
            PassId.AnimationSpeed = 200;
            PassId.AutoCompleteMode = AutoCompleteMode.None;
            PassId.AutoCompleteSource = AutoCompleteSource.None;
            PassId.AutoSizeHeight = true;
            PassId.BackColor = Color.White;
            PassId.BackgroundImage = (Image)resources.GetObject("PassId.BackgroundImage");
            PassId.BorderColorActive = Color.DodgerBlue;
            PassId.BorderColorDisabled = Color.FromArgb(204, 204, 204);
            PassId.BorderColorHover = Color.FromArgb(105, 181, 255);
            PassId.BorderColorIdle = Color.Silver;
            PassId.BorderRadius = 1;
            PassId.BorderThickness = 1;
            PassId.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            PassId.CharacterCasing = CharacterCasing.Normal;
            PassId.Cursor = Cursors.IBeam;
            PassId.DefaultFont = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            PassId.DefaultText = "";
            PassId.FillColor = Color.White;
            PassId.ForeColor = Color.Red;
            PassId.HideSelection = true;
            PassId.IconLeft = null;
            PassId.IconLeftCursor = Cursors.IBeam;
            PassId.IconPadding = 10;
            PassId.IconRight = null;
            PassId.IconRightCursor = Cursors.IBeam;
            PassId.Location = new Point(211, 153);
            PassId.MaxLength = 32767;
            PassId.MinimumSize = new Size(1, 1);
            PassId.Modified = false;
            PassId.Multiline = false;
            PassId.Name = "PassId";
            stateProperties1.BorderColor = Color.DodgerBlue;
            stateProperties1.FillColor = Color.Empty;
            stateProperties1.ForeColor = Color.Empty;
            stateProperties1.PlaceholderForeColor = Color.Empty;
            PassId.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = Color.FromArgb(204, 204, 204);
            stateProperties2.FillColor = Color.FromArgb(240, 240, 240);
            stateProperties2.ForeColor = Color.FromArgb(109, 109, 109);
            stateProperties2.PlaceholderForeColor = Color.DarkGray;
            PassId.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = Color.FromArgb(105, 181, 255);
            stateProperties3.FillColor = Color.Empty;
            stateProperties3.ForeColor = Color.Empty;
            stateProperties3.PlaceholderForeColor = Color.Empty;
            PassId.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = Color.Silver;
            stateProperties4.FillColor = Color.White;
            stateProperties4.ForeColor = Color.Red;
            stateProperties4.PlaceholderForeColor = Color.Empty;
            PassId.OnIdleState = stateProperties4;
            PassId.Padding = new Padding(3);
            PassId.PasswordChar = '\0';
            PassId.PlaceholderForeColor = Color.Silver;
            PassId.PlaceholderText = "Enter text";
            PassId.ReadOnly = false;
            PassId.ScrollBars = ScrollBars.None;
            PassId.SelectedText = "";
            PassId.SelectionLength = 0;
            PassId.SelectionStart = 0;
            PassId.ShortcutsEnabled = true;
            PassId.Size = new Size(163, 23);
            PassId.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            PassId.TabIndex = 10;
            PassId.TextAlign = HorizontalAlignment.Left;
            PassId.TextMarginBottom = 0;
            PassId.TextMarginLeft = 3;
            PassId.TextMarginTop = 1;
            PassId.TextPlaceholder = "Enter text";
            PassId.UseSystemPasswordChar = false;
            PassId.WordWrap = true;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.Navy;
            label4.Location = new Point(12, 198);
            label4.Name = "label4";
            label4.Size = new Size(175, 23);
            label4.TabIndex = 13;
            label4.Text = "Passenger Name";
            // 
            // PassName
            // 
            PassName.AcceptsReturn = false;
            PassName.AcceptsTab = false;
            PassName.AnimationSpeed = 200;
            PassName.AutoCompleteMode = AutoCompleteMode.None;
            PassName.AutoCompleteSource = AutoCompleteSource.None;
            PassName.AutoSizeHeight = true;
            PassName.BackColor = Color.White;
            PassName.BackgroundImage = (Image)resources.GetObject("PassName.BackgroundImage");
            PassName.BorderColorActive = Color.DodgerBlue;
            PassName.BorderColorDisabled = Color.FromArgb(204, 204, 204);
            PassName.BorderColorHover = Color.FromArgb(105, 181, 255);
            PassName.BorderColorIdle = Color.Silver;
            PassName.BorderRadius = 1;
            PassName.BorderThickness = 1;
            PassName.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            PassName.CharacterCasing = CharacterCasing.Normal;
            PassName.Cursor = Cursors.IBeam;
            PassName.DefaultFont = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            PassName.DefaultText = "";
            PassName.FillColor = Color.White;
            PassName.ForeColor = Color.Red;
            PassName.HideSelection = true;
            PassName.IconLeft = null;
            PassName.IconLeftCursor = Cursors.IBeam;
            PassName.IconPadding = 10;
            PassName.IconRight = null;
            PassName.IconRightCursor = Cursors.IBeam;
            PassName.Location = new Point(211, 198);
            PassName.MaxLength = 32767;
            PassName.MinimumSize = new Size(1, 1);
            PassName.Modified = false;
            PassName.Multiline = false;
            PassName.Name = "PassName";
            stateProperties5.BorderColor = Color.DodgerBlue;
            stateProperties5.FillColor = Color.Empty;
            stateProperties5.ForeColor = Color.Empty;
            stateProperties5.PlaceholderForeColor = Color.Empty;
            PassName.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = Color.FromArgb(204, 204, 204);
            stateProperties6.FillColor = Color.FromArgb(240, 240, 240);
            stateProperties6.ForeColor = Color.FromArgb(109, 109, 109);
            stateProperties6.PlaceholderForeColor = Color.DarkGray;
            PassName.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = Color.FromArgb(105, 181, 255);
            stateProperties7.FillColor = Color.Empty;
            stateProperties7.ForeColor = Color.Empty;
            stateProperties7.PlaceholderForeColor = Color.Empty;
            PassName.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = Color.Silver;
            stateProperties8.FillColor = Color.White;
            stateProperties8.ForeColor = Color.Red;
            stateProperties8.PlaceholderForeColor = Color.Empty;
            PassName.OnIdleState = stateProperties8;
            PassName.Padding = new Padding(3);
            PassName.PasswordChar = '\0';
            PassName.PlaceholderForeColor = Color.Silver;
            PassName.PlaceholderText = "Enter text";
            PassName.ReadOnly = false;
            PassName.ScrollBars = ScrollBars.None;
            PassName.SelectedText = "";
            PassName.SelectionLength = 0;
            PassName.SelectionStart = 0;
            PassName.ShortcutsEnabled = true;
            PassName.Size = new Size(163, 23);
            PassName.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            PassName.TabIndex = 12;
            PassName.TextAlign = HorizontalAlignment.Left;
            PassName.TextMarginBottom = 0;
            PassName.TextMarginLeft = 3;
            PassName.TextMarginTop = 1;
            PassName.TextPlaceholder = "Enter text";
            PassName.UseSystemPasswordChar = false;
            PassName.WordWrap = true;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.Navy;
            label5.Location = new Point(12, 247);
            label5.Name = "label5";
            label5.Size = new Size(174, 23);
            label5.TabIndex = 15;
            label5.Text = "Passport Number";
            // 
            // PassportTb
            // 
            PassportTb.AcceptsReturn = false;
            PassportTb.AcceptsTab = false;
            PassportTb.AnimationSpeed = 200;
            PassportTb.AutoCompleteMode = AutoCompleteMode.None;
            PassportTb.AutoCompleteSource = AutoCompleteSource.None;
            PassportTb.AutoSizeHeight = true;
            PassportTb.BackColor = Color.White;
            PassportTb.BackgroundImage = (Image)resources.GetObject("PassportTb.BackgroundImage");
            PassportTb.BorderColorActive = Color.DodgerBlue;
            PassportTb.BorderColorDisabled = Color.FromArgb(204, 204, 204);
            PassportTb.BorderColorHover = Color.FromArgb(105, 181, 255);
            PassportTb.BorderColorIdle = Color.Silver;
            PassportTb.BorderRadius = 1;
            PassportTb.BorderThickness = 1;
            PassportTb.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            PassportTb.CharacterCasing = CharacterCasing.Normal;
            PassportTb.Cursor = Cursors.IBeam;
            PassportTb.DefaultFont = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            PassportTb.DefaultText = "";
            PassportTb.FillColor = Color.White;
            PassportTb.ForeColor = Color.Red;
            PassportTb.HideSelection = true;
            PassportTb.IconLeft = null;
            PassportTb.IconLeftCursor = Cursors.IBeam;
            PassportTb.IconPadding = 10;
            PassportTb.IconRight = null;
            PassportTb.IconRightCursor = Cursors.IBeam;
            PassportTb.Location = new Point(211, 247);
            PassportTb.MaxLength = 32767;
            PassportTb.MinimumSize = new Size(1, 1);
            PassportTb.Modified = false;
            PassportTb.Multiline = false;
            PassportTb.Name = "PassportTb";
            stateProperties9.BorderColor = Color.DodgerBlue;
            stateProperties9.FillColor = Color.Empty;
            stateProperties9.ForeColor = Color.Empty;
            stateProperties9.PlaceholderForeColor = Color.Empty;
            PassportTb.OnActiveState = stateProperties9;
            stateProperties10.BorderColor = Color.FromArgb(204, 204, 204);
            stateProperties10.FillColor = Color.FromArgb(240, 240, 240);
            stateProperties10.ForeColor = Color.FromArgb(109, 109, 109);
            stateProperties10.PlaceholderForeColor = Color.DarkGray;
            PassportTb.OnDisabledState = stateProperties10;
            stateProperties11.BorderColor = Color.FromArgb(105, 181, 255);
            stateProperties11.FillColor = Color.Empty;
            stateProperties11.ForeColor = Color.Empty;
            stateProperties11.PlaceholderForeColor = Color.Empty;
            PassportTb.OnHoverState = stateProperties11;
            stateProperties12.BorderColor = Color.Silver;
            stateProperties12.FillColor = Color.White;
            stateProperties12.ForeColor = Color.Red;
            stateProperties12.PlaceholderForeColor = Color.Empty;
            PassportTb.OnIdleState = stateProperties12;
            PassportTb.Padding = new Padding(3);
            PassportTb.PasswordChar = '\0';
            PassportTb.PlaceholderForeColor = Color.Silver;
            PassportTb.PlaceholderText = "Enter text";
            PassportTb.ReadOnly = false;
            PassportTb.ScrollBars = ScrollBars.None;
            PassportTb.SelectedText = "";
            PassportTb.SelectionLength = 0;
            PassportTb.SelectionStart = 0;
            PassportTb.ShortcutsEnabled = true;
            PassportTb.Size = new Size(163, 23);
            PassportTb.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            PassportTb.TabIndex = 14;
            PassportTb.TextAlign = HorizontalAlignment.Left;
            PassportTb.TextMarginBottom = 0;
            PassportTb.TextMarginLeft = 3;
            PassportTb.TextMarginTop = 1;
            PassportTb.TextPlaceholder = "Enter text";
            PassportTb.UseSystemPasswordChar = false;
            PassportTb.WordWrap = true;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.Navy;
            label6.Location = new Point(12, 290);
            label6.Name = "label6";
            label6.Size = new Size(193, 23);
            label6.TabIndex = 17;
            label6.Text = "Passenger Address";
            // 
            // PassAd
            // 
            PassAd.AcceptsReturn = false;
            PassAd.AcceptsTab = false;
            PassAd.AnimationSpeed = 200;
            PassAd.AutoCompleteMode = AutoCompleteMode.None;
            PassAd.AutoCompleteSource = AutoCompleteSource.None;
            PassAd.AutoSizeHeight = true;
            PassAd.BackColor = Color.White;
            PassAd.BackgroundImage = (Image)resources.GetObject("PassAd.BackgroundImage");
            PassAd.BorderColorActive = Color.DodgerBlue;
            PassAd.BorderColorDisabled = Color.FromArgb(204, 204, 204);
            PassAd.BorderColorHover = Color.FromArgb(105, 181, 255);
            PassAd.BorderColorIdle = Color.Silver;
            PassAd.BorderRadius = 1;
            PassAd.BorderThickness = 1;
            PassAd.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            PassAd.CharacterCasing = CharacterCasing.Normal;
            PassAd.Cursor = Cursors.IBeam;
            PassAd.DefaultFont = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            PassAd.DefaultText = "";
            PassAd.FillColor = Color.White;
            PassAd.ForeColor = Color.Red;
            PassAd.HideSelection = true;
            PassAd.IconLeft = null;
            PassAd.IconLeftCursor = Cursors.IBeam;
            PassAd.IconPadding = 10;
            PassAd.IconRight = null;
            PassAd.IconRightCursor = Cursors.IBeam;
            PassAd.Location = new Point(211, 290);
            PassAd.MaxLength = 32767;
            PassAd.MinimumSize = new Size(1, 1);
            PassAd.Modified = false;
            PassAd.Multiline = false;
            PassAd.Name = "PassAd";
            stateProperties13.BorderColor = Color.DodgerBlue;
            stateProperties13.FillColor = Color.Empty;
            stateProperties13.ForeColor = Color.Empty;
            stateProperties13.PlaceholderForeColor = Color.Empty;
            PassAd.OnActiveState = stateProperties13;
            stateProperties14.BorderColor = Color.FromArgb(204, 204, 204);
            stateProperties14.FillColor = Color.FromArgb(240, 240, 240);
            stateProperties14.ForeColor = Color.FromArgb(109, 109, 109);
            stateProperties14.PlaceholderForeColor = Color.DarkGray;
            PassAd.OnDisabledState = stateProperties14;
            stateProperties15.BorderColor = Color.FromArgb(105, 181, 255);
            stateProperties15.FillColor = Color.Empty;
            stateProperties15.ForeColor = Color.Empty;
            stateProperties15.PlaceholderForeColor = Color.Empty;
            PassAd.OnHoverState = stateProperties15;
            stateProperties16.BorderColor = Color.Silver;
            stateProperties16.FillColor = Color.White;
            stateProperties16.ForeColor = Color.Red;
            stateProperties16.PlaceholderForeColor = Color.Empty;
            PassAd.OnIdleState = stateProperties16;
            PassAd.Padding = new Padding(3);
            PassAd.PasswordChar = '\0';
            PassAd.PlaceholderForeColor = Color.Silver;
            PassAd.PlaceholderText = "Enter text";
            PassAd.ReadOnly = false;
            PassAd.ScrollBars = ScrollBars.None;
            PassAd.SelectedText = "";
            PassAd.SelectionLength = 0;
            PassAd.SelectionStart = 0;
            PassAd.ShortcutsEnabled = true;
            PassAd.Size = new Size(163, 23);
            PassAd.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            PassAd.TabIndex = 16;
            PassAd.TextAlign = HorizontalAlignment.Left;
            PassAd.TextMarginBottom = 0;
            PassAd.TextMarginLeft = 3;
            PassAd.TextMarginTop = 1;
            PassAd.TextPlaceholder = "Enter text";
            PassAd.UseSystemPasswordChar = false;
            PassAd.WordWrap = true;
            // 
            // NationalityCb
            // 
            NationalityCb.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            NationalityCb.FormattingEnabled = true;
            NationalityCb.Items.AddRange(new object[] { "BANGLADESHI", "INDIAN", "PAKISTANI", "PALESTANIAN", "AMERICAN", "GERMAN", "CONGOLESE", "FINISH", "NIGERIAN", "SPANISH", "TURKISH" });
            NationalityCb.Location = new Point(211, 327);
            NationalityCb.Name = "NationalityCb";
            NationalityCb.Size = new Size(163, 31);
            NationalityCb.TabIndex = 19;
            NationalityCb.SelectedIndexChanged += NationalityCb_SelectedIndexChanged;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.Navy;
            label7.Location = new Point(12, 335);
            label7.Name = "label7";
            label7.Size = new Size(115, 23);
            label7.TabIndex = 18;
            label7.Text = "Nationality";
            // 
            // GenderCb
            // 
            GenderCb.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            GenderCb.FormattingEnabled = true;
            GenderCb.Items.AddRange(new object[] { "MALE", "FEMALE" });
            GenderCb.Location = new Point(211, 372);
            GenderCb.Name = "GenderCb";
            GenderCb.Size = new Size(163, 31);
            GenderCb.TabIndex = 21;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.Navy;
            label8.Location = new Point(12, 375);
            label8.Name = "label8";
            label8.Size = new Size(84, 23);
            label8.TabIndex = 20;
            label8.Text = "Gender";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.Navy;
            label9.Location = new Point(12, 421);
            label9.Name = "label9";
            label9.Size = new Size(71, 23);
            label9.TabIndex = 22;
            label9.Text = "Phone";
            // 
            // PhoneTb
            // 
            PhoneTb.AcceptsReturn = false;
            PhoneTb.AcceptsTab = false;
            PhoneTb.AnimationSpeed = 200;
            PhoneTb.AutoCompleteMode = AutoCompleteMode.None;
            PhoneTb.AutoCompleteSource = AutoCompleteSource.None;
            PhoneTb.AutoSizeHeight = true;
            PhoneTb.BackColor = Color.White;
            PhoneTb.BackgroundImage = (Image)resources.GetObject("PhoneTb.BackgroundImage");
            PhoneTb.BorderColorActive = Color.DodgerBlue;
            PhoneTb.BorderColorDisabled = Color.FromArgb(204, 204, 204);
            PhoneTb.BorderColorHover = Color.FromArgb(105, 181, 255);
            PhoneTb.BorderColorIdle = Color.Silver;
            PhoneTb.BorderRadius = 1;
            PhoneTb.BorderThickness = 1;
            PhoneTb.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            PhoneTb.CharacterCasing = CharacterCasing.Normal;
            PhoneTb.Cursor = Cursors.IBeam;
            PhoneTb.DefaultFont = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            PhoneTb.DefaultText = "";
            PhoneTb.FillColor = Color.White;
            PhoneTb.ForeColor = Color.Red;
            PhoneTb.HideSelection = true;
            PhoneTb.IconLeft = null;
            PhoneTb.IconLeftCursor = Cursors.IBeam;
            PhoneTb.IconPadding = 10;
            PhoneTb.IconRight = null;
            PhoneTb.IconRightCursor = Cursors.IBeam;
            PhoneTb.Location = new Point(211, 421);
            PhoneTb.MaxLength = 32767;
            PhoneTb.MinimumSize = new Size(1, 1);
            PhoneTb.Modified = false;
            PhoneTb.Multiline = false;
            PhoneTb.Name = "PhoneTb";
            stateProperties17.BorderColor = Color.DodgerBlue;
            stateProperties17.FillColor = Color.Empty;
            stateProperties17.ForeColor = Color.Empty;
            stateProperties17.PlaceholderForeColor = Color.Empty;
            PhoneTb.OnActiveState = stateProperties17;
            stateProperties18.BorderColor = Color.FromArgb(204, 204, 204);
            stateProperties18.FillColor = Color.FromArgb(240, 240, 240);
            stateProperties18.ForeColor = Color.FromArgb(109, 109, 109);
            stateProperties18.PlaceholderForeColor = Color.DarkGray;
            PhoneTb.OnDisabledState = stateProperties18;
            stateProperties19.BorderColor = Color.FromArgb(105, 181, 255);
            stateProperties19.FillColor = Color.Empty;
            stateProperties19.ForeColor = Color.Empty;
            stateProperties19.PlaceholderForeColor = Color.Empty;
            PhoneTb.OnHoverState = stateProperties19;
            stateProperties20.BorderColor = Color.Silver;
            stateProperties20.FillColor = Color.White;
            stateProperties20.ForeColor = Color.Red;
            stateProperties20.PlaceholderForeColor = Color.Empty;
            PhoneTb.OnIdleState = stateProperties20;
            PhoneTb.Padding = new Padding(3);
            PhoneTb.PasswordChar = '\0';
            PhoneTb.PlaceholderForeColor = Color.Silver;
            PhoneTb.PlaceholderText = "Enter text";
            PhoneTb.ReadOnly = false;
            PhoneTb.ScrollBars = ScrollBars.None;
            PhoneTb.SelectedText = "";
            PhoneTb.SelectionLength = 0;
            PhoneTb.SelectionStart = 0;
            PhoneTb.ShortcutsEnabled = true;
            PhoneTb.Size = new Size(163, 23);
            PhoneTb.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            PhoneTb.TabIndex = 23;
            PhoneTb.TextAlign = HorizontalAlignment.Left;
            PhoneTb.TextMarginBottom = 0;
            PhoneTb.TextMarginLeft = 3;
            PhoneTb.TextMarginTop = 1;
            PhoneTb.TextPlaceholder = "Enter text";
            PhoneTb.UseSystemPasswordChar = false;
            PhoneTb.WordWrap = true;
            // 
            // button2
            // 
            button2.BackColor = Color.Navy;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.White;
            button2.Location = new Point(310, 470);
            button2.Name = "button2";
            button2.Size = new Size(94, 32);
            button2.TabIndex = 25;
            button2.Text = "Reset";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.Navy;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.White;
            button1.Location = new Point(198, 470);
            button1.Name = "button1";
            button1.Size = new Size(94, 32);
            button1.TabIndex = 24;
            button1.Text = "Record";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Century Gothic", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.Red;
            label10.Location = new Point(596, 0);
            label10.Name = "label10";
            label10.Size = new Size(28, 27);
            label10.TabIndex = 26;
            label10.Text = "X";
            label10.Click += label10_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(406, 186);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(194, 192);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 27;
            pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Navy;
            panel1.Controls.Add(label10);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(624, 28);
            panel1.TabIndex = 28;
            // 
            // button3
            // 
            button3.BackColor = Color.Navy;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.ForeColor = Color.White;
            button3.Location = new Point(266, 508);
            button3.Name = "button3";
            button3.Size = new Size(182, 32);
            button3.TabIndex = 29;
            button3.Text = "View Passengers";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.Navy;
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button4.ForeColor = Color.White;
            button4.Location = new Point(418, 470);
            button4.Name = "button4";
            button4.Size = new Size(94, 32);
            button4.TabIndex = 30;
            button4.Text = "Back";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // AddPassenger
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(624, 552);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(panel1);
            Controls.Add(pictureBox1);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(PhoneTb);
            Controls.Add(label9);
            Controls.Add(GenderCb);
            Controls.Add(label8);
            Controls.Add(NationalityCb);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(PassAd);
            Controls.Add(label5);
            Controls.Add(PassportTb);
            Controls.Add(label4);
            Controls.Add(PassName);
            Controls.Add(label3);
            Controls.Add(PassId);
            Controls.Add(label2);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "AddPassenger";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "AddPassenger";
            Load += AddPassenger_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label2;
        private Label label1;
        private Label label3;
        private Bunifu.UI.WinForms.BunifuTextBox PassId;
        private Label label4;
        private Bunifu.UI.WinForms.BunifuTextBox PassName;
        private Label label5;
        private Bunifu.UI.WinForms.BunifuTextBox PassportTb;
        private Label label6;
        private Bunifu.UI.WinForms.BunifuTextBox PassAd;
        private ComboBox NationalityCb;
        private Label label7;
        private ComboBox GenderCb;
        private Label label8;
        private Label label9;
        private Bunifu.UI.WinForms.BunifuTextBox PhoneTb;
        private Button button2;
        private Button button1;
        private Label label10;
        private PictureBox pictureBox1;
        private Panel panel1;
        private Button button3;
        private Button button4;
    }
}