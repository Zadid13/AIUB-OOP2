﻿namespace Airline_Management_System
{
    partial class ViewPassenger
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ViewPassenger));
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties21 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties22 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties23 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties24 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties25 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties26 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties27 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties28 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties29 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties30 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties31 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties32 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties33 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties34 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties35 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties36 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties37 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties38 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties39 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties40 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            label2 = new Label();
            label1 = new Label();
            label6 = new Label();
            label5 = new Label();
            PpassTb = new Bunifu.UI.WinForms.BunifuTextBox();
            label3 = new Label();
            PidTb = new Bunifu.UI.WinForms.BunifuTextBox();
            label7 = new Label();
            PnameTb = new Bunifu.UI.WinForms.BunifuTextBox();
            PaddTb = new Bunifu.UI.WinForms.BunifuTextBox();
            label8 = new Label();
            natcb = new ComboBox();
            label9 = new Label();
            GendCb = new ComboBox();
            label10 = new Label();
            PphoneTb = new Bunifu.UI.WinForms.BunifuTextBox();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            PassengerDGV = new Guna.UI2.WinForms.Guna2DataGridView();
            panel1 = new Panel();
            panel2 = new Panel();
            panel3 = new Panel();
            label4 = new Label();
            ((System.ComponentModel.ISupportInitialize)PassengerDGV).BeginInit();
            panel1.SuspendLayout();
            panel3.SuspendLayout();
            SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Century Gothic", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Red;
            label2.Location = new Point(345, 78);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(240, 34);
            label2.TabIndex = 7;
            label2.Text = "View Passengers";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Red;
            label1.Location = new Point(295, 44);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(360, 34);
            label1.TabIndex = 6;
            label1.Text = "Biman Bangladesh Airline";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.Navy;
            label6.Location = new Point(567, 199);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(88, 23);
            label6.TabIndex = 25;
            label6.Text = "Address";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.Navy;
            label5.Location = new Point(90, 208);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(90, 23);
            label5.TabIndex = 23;
            label5.Text = "Passport";
            // 
            // PpassTb
            // 
            PpassTb.AcceptsReturn = false;
            PpassTb.AcceptsTab = false;
            PpassTb.AnimationSpeed = 200;
            PpassTb.AutoCompleteMode = AutoCompleteMode.None;
            PpassTb.AutoCompleteSource = AutoCompleteSource.None;
            PpassTb.AutoSizeHeight = true;
            PpassTb.BackColor = Color.White;
            PpassTb.BackgroundImage = (Image)resources.GetObject("PpassTb.BackgroundImage");
            PpassTb.BorderColorActive = Color.DodgerBlue;
            PpassTb.BorderColorDisabled = Color.FromArgb(204, 204, 204);
            PpassTb.BorderColorHover = Color.FromArgb(105, 181, 255);
            PpassTb.BorderColorIdle = Color.Silver;
            PpassTb.BorderRadius = 1;
            PpassTb.BorderThickness = 1;
            PpassTb.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            PpassTb.CharacterCasing = CharacterCasing.Normal;
            PpassTb.Cursor = Cursors.IBeam;
            PpassTb.DefaultFont = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            PpassTb.DefaultText = "";
            PpassTb.FillColor = Color.White;
            PpassTb.ForeColor = Color.Red;
            PpassTb.HideSelection = true;
            PpassTb.IconLeft = null;
            PpassTb.IconLeftCursor = Cursors.IBeam;
            PpassTb.IconPadding = 10;
            PpassTb.IconRight = null;
            PpassTb.IconRightCursor = Cursors.IBeam;
            PpassTb.Location = new Point(253, 199);
            PpassTb.Margin = new Padding(4, 3, 4, 3);
            PpassTb.MaxLength = 32767;
            PpassTb.MinimumSize = new Size(2, 1);
            PpassTb.Modified = false;
            PpassTb.Multiline = false;
            PpassTb.Name = "PpassTb";
            stateProperties21.BorderColor = Color.DodgerBlue;
            stateProperties21.FillColor = Color.Empty;
            stateProperties21.ForeColor = Color.Empty;
            stateProperties21.PlaceholderForeColor = Color.Empty;
            PpassTb.OnActiveState = stateProperties21;
            stateProperties22.BorderColor = Color.FromArgb(204, 204, 204);
            stateProperties22.FillColor = Color.FromArgb(240, 240, 240);
            stateProperties22.ForeColor = Color.FromArgb(109, 109, 109);
            stateProperties22.PlaceholderForeColor = Color.DarkGray;
            PpassTb.OnDisabledState = stateProperties22;
            stateProperties23.BorderColor = Color.FromArgb(105, 181, 255);
            stateProperties23.FillColor = Color.Empty;
            stateProperties23.ForeColor = Color.Empty;
            stateProperties23.PlaceholderForeColor = Color.Empty;
            PpassTb.OnHoverState = stateProperties23;
            stateProperties24.BorderColor = Color.Silver;
            stateProperties24.FillColor = Color.White;
            stateProperties24.ForeColor = Color.Red;
            stateProperties24.PlaceholderForeColor = Color.Empty;
            PpassTb.OnIdleState = stateProperties24;
            PpassTb.Padding = new Padding(4, 3, 4, 3);
            PpassTb.PasswordChar = '\0';
            PpassTb.PlaceholderForeColor = Color.Silver;
            PpassTb.PlaceholderText = "Enter text";
            PpassTb.ReadOnly = false;
            PpassTb.ScrollBars = ScrollBars.None;
            PpassTb.SelectedText = "";
            PpassTb.SelectionLength = 0;
            PpassTb.SelectionStart = 0;
            PpassTb.ShortcutsEnabled = true;
            PpassTb.Size = new Size(244, 41);
            PpassTb.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            PpassTb.TabIndex = 20;
            PpassTb.TextAlign = HorizontalAlignment.Left;
            PpassTb.TextMarginBottom = 0;
            PpassTb.TextMarginLeft = 3;
            PpassTb.TextMarginTop = 1;
            PpassTb.TextPlaceholder = "Enter text";
            PpassTb.UseSystemPasswordChar = false;
            PpassTb.WordWrap = true;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Navy;
            label3.Location = new Point(90, 147);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(134, 23);
            label3.TabIndex = 19;
            label3.Text = "Passenger Id";
            // 
            // PidTb
            // 
            PidTb.AcceptsReturn = false;
            PidTb.AcceptsTab = false;
            PidTb.AnimationSpeed = 200;
            PidTb.AutoCompleteMode = AutoCompleteMode.None;
            PidTb.AutoCompleteSource = AutoCompleteSource.None;
            PidTb.AutoSizeHeight = true;
            PidTb.BackColor = Color.White;
            PidTb.BackgroundImage = (Image)resources.GetObject("PidTb.BackgroundImage");
            PidTb.BorderColorActive = Color.DodgerBlue;
            PidTb.BorderColorDisabled = Color.FromArgb(204, 204, 204);
            PidTb.BorderColorHover = Color.FromArgb(105, 181, 255);
            PidTb.BorderColorIdle = Color.Silver;
            PidTb.BorderRadius = 1;
            PidTb.BorderThickness = 1;
            PidTb.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            PidTb.CharacterCasing = CharacterCasing.Normal;
            PidTb.Cursor = Cursors.IBeam;
            PidTb.DefaultFont = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            PidTb.DefaultText = "";
            PidTb.FillColor = Color.White;
            PidTb.ForeColor = Color.Red;
            PidTb.HideSelection = true;
            PidTb.IconLeft = null;
            PidTb.IconLeftCursor = Cursors.IBeam;
            PidTb.IconPadding = 10;
            PidTb.IconRight = null;
            PidTb.IconRightCursor = Cursors.IBeam;
            PidTb.Location = new Point(253, 138);
            PidTb.Margin = new Padding(4, 3, 4, 3);
            PidTb.MaxLength = 32767;
            PidTb.MinimumSize = new Size(2, 1);
            PidTb.Modified = false;
            PidTb.Multiline = false;
            PidTb.Name = "PidTb";
            stateProperties25.BorderColor = Color.DodgerBlue;
            stateProperties25.FillColor = Color.Empty;
            stateProperties25.ForeColor = Color.Empty;
            stateProperties25.PlaceholderForeColor = Color.Empty;
            PidTb.OnActiveState = stateProperties25;
            stateProperties26.BorderColor = Color.FromArgb(204, 204, 204);
            stateProperties26.FillColor = Color.FromArgb(240, 240, 240);
            stateProperties26.ForeColor = Color.FromArgb(109, 109, 109);
            stateProperties26.PlaceholderForeColor = Color.DarkGray;
            PidTb.OnDisabledState = stateProperties26;
            stateProperties27.BorderColor = Color.FromArgb(105, 181, 255);
            stateProperties27.FillColor = Color.Empty;
            stateProperties27.ForeColor = Color.Empty;
            stateProperties27.PlaceholderForeColor = Color.Empty;
            PidTb.OnHoverState = stateProperties27;
            stateProperties28.BorderColor = Color.Silver;
            stateProperties28.FillColor = Color.White;
            stateProperties28.ForeColor = Color.Red;
            stateProperties28.PlaceholderForeColor = Color.Empty;
            PidTb.OnIdleState = stateProperties28;
            PidTb.Padding = new Padding(4, 3, 4, 3);
            PidTb.PasswordChar = '\0';
            PidTb.PlaceholderForeColor = Color.Silver;
            PidTb.PlaceholderText = "Enter text";
            PidTb.ReadOnly = false;
            PidTb.ScrollBars = ScrollBars.None;
            PidTb.SelectedText = "";
            PidTb.SelectionLength = 0;
            PidTb.SelectionStart = 0;
            PidTb.ShortcutsEnabled = true;
            PidTb.Size = new Size(244, 41);
            PidTb.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            PidTb.TabIndex = 18;
            PidTb.TextAlign = HorizontalAlignment.Left;
            PidTb.TextMarginBottom = 0;
            PidTb.TextMarginLeft = 3;
            PidTb.TextMarginTop = 1;
            PidTb.TextPlaceholder = "Enter text";
            PidTb.UseSystemPasswordChar = false;
            PidTb.WordWrap = true;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.Navy;
            label7.Location = new Point(567, 147);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(70, 23);
            label7.TabIndex = 27;
            label7.Text = "Name";
            // 
            // PnameTb
            // 
            PnameTb.AcceptsReturn = false;
            PnameTb.AcceptsTab = false;
            PnameTb.AnimationSpeed = 200;
            PnameTb.AutoCompleteMode = AutoCompleteMode.None;
            PnameTb.AutoCompleteSource = AutoCompleteSource.None;
            PnameTb.AutoSizeHeight = true;
            PnameTb.BackColor = Color.White;
            PnameTb.BackgroundImage = (Image)resources.GetObject("PnameTb.BackgroundImage");
            PnameTb.BorderColorActive = Color.DodgerBlue;
            PnameTb.BorderColorDisabled = Color.FromArgb(204, 204, 204);
            PnameTb.BorderColorHover = Color.FromArgb(105, 181, 255);
            PnameTb.BorderColorIdle = Color.Silver;
            PnameTb.BorderRadius = 1;
            PnameTb.BorderThickness = 1;
            PnameTb.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            PnameTb.CharacterCasing = CharacterCasing.Normal;
            PnameTb.Cursor = Cursors.IBeam;
            PnameTb.DefaultFont = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            PnameTb.DefaultText = "";
            PnameTb.FillColor = Color.White;
            PnameTb.ForeColor = Color.Red;
            PnameTb.HideSelection = true;
            PnameTb.IconLeft = null;
            PnameTb.IconLeftCursor = Cursors.IBeam;
            PnameTb.IconPadding = 10;
            PnameTb.IconRight = null;
            PnameTb.IconRightCursor = Cursors.IBeam;
            PnameTb.Location = new Point(690, 147);
            PnameTb.Margin = new Padding(4, 3, 4, 3);
            PnameTb.MaxLength = 32767;
            PnameTb.MinimumSize = new Size(2, 1);
            PnameTb.Modified = false;
            PnameTb.Multiline = false;
            PnameTb.Name = "PnameTb";
            stateProperties29.BorderColor = Color.DodgerBlue;
            stateProperties29.FillColor = Color.Empty;
            stateProperties29.ForeColor = Color.Empty;
            stateProperties29.PlaceholderForeColor = Color.Empty;
            PnameTb.OnActiveState = stateProperties29;
            stateProperties30.BorderColor = Color.FromArgb(204, 204, 204);
            stateProperties30.FillColor = Color.FromArgb(240, 240, 240);
            stateProperties30.ForeColor = Color.FromArgb(109, 109, 109);
            stateProperties30.PlaceholderForeColor = Color.DarkGray;
            PnameTb.OnDisabledState = stateProperties30;
            stateProperties31.BorderColor = Color.FromArgb(105, 181, 255);
            stateProperties31.FillColor = Color.Empty;
            stateProperties31.ForeColor = Color.Empty;
            stateProperties31.PlaceholderForeColor = Color.Empty;
            PnameTb.OnHoverState = stateProperties31;
            stateProperties32.BorderColor = Color.Silver;
            stateProperties32.FillColor = Color.White;
            stateProperties32.ForeColor = Color.Red;
            stateProperties32.PlaceholderForeColor = Color.Empty;
            PnameTb.OnIdleState = stateProperties32;
            PnameTb.Padding = new Padding(4, 3, 4, 3);
            PnameTb.PasswordChar = '\0';
            PnameTb.PlaceholderForeColor = Color.Silver;
            PnameTb.PlaceholderText = "Enter text";
            PnameTb.ReadOnly = false;
            PnameTb.ScrollBars = ScrollBars.None;
            PnameTb.SelectedText = "";
            PnameTb.SelectionLength = 0;
            PnameTb.SelectionStart = 0;
            PnameTb.ShortcutsEnabled = true;
            PnameTb.Size = new Size(244, 41);
            PnameTb.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            PnameTb.TabIndex = 26;
            PnameTb.TextAlign = HorizontalAlignment.Left;
            PnameTb.TextMarginBottom = 0;
            PnameTb.TextMarginLeft = 3;
            PnameTb.TextMarginTop = 1;
            PnameTb.TextPlaceholder = "Enter text";
            PnameTb.UseSystemPasswordChar = false;
            PnameTb.WordWrap = true;
            // 
            // PaddTb
            // 
            PaddTb.AcceptsReturn = false;
            PaddTb.AcceptsTab = false;
            PaddTb.AnimationSpeed = 200;
            PaddTb.AutoCompleteMode = AutoCompleteMode.None;
            PaddTb.AutoCompleteSource = AutoCompleteSource.None;
            PaddTb.AutoSizeHeight = true;
            PaddTb.BackColor = Color.White;
            PaddTb.BackgroundImage = (Image)resources.GetObject("PaddTb.BackgroundImage");
            PaddTb.BorderColorActive = Color.DodgerBlue;
            PaddTb.BorderColorDisabled = Color.FromArgb(204, 204, 204);
            PaddTb.BorderColorHover = Color.FromArgb(105, 181, 255);
            PaddTb.BorderColorIdle = Color.Silver;
            PaddTb.BorderRadius = 1;
            PaddTb.BorderThickness = 1;
            PaddTb.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            PaddTb.CharacterCasing = CharacterCasing.Normal;
            PaddTb.Cursor = Cursors.IBeam;
            PaddTb.DefaultFont = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            PaddTb.DefaultText = "";
            PaddTb.FillColor = Color.White;
            PaddTb.ForeColor = Color.Red;
            PaddTb.HideSelection = true;
            PaddTb.IconLeft = null;
            PaddTb.IconLeftCursor = Cursors.IBeam;
            PaddTb.IconPadding = 10;
            PaddTb.IconRight = null;
            PaddTb.IconRightCursor = Cursors.IBeam;
            PaddTb.Location = new Point(690, 199);
            PaddTb.Margin = new Padding(4, 3, 4, 3);
            PaddTb.MaxLength = 32767;
            PaddTb.MinimumSize = new Size(2, 1);
            PaddTb.Modified = false;
            PaddTb.Multiline = false;
            PaddTb.Name = "PaddTb";
            stateProperties33.BorderColor = Color.DodgerBlue;
            stateProperties33.FillColor = Color.Empty;
            stateProperties33.ForeColor = Color.Empty;
            stateProperties33.PlaceholderForeColor = Color.Empty;
            PaddTb.OnActiveState = stateProperties33;
            stateProperties34.BorderColor = Color.FromArgb(204, 204, 204);
            stateProperties34.FillColor = Color.FromArgb(240, 240, 240);
            stateProperties34.ForeColor = Color.FromArgb(109, 109, 109);
            stateProperties34.PlaceholderForeColor = Color.DarkGray;
            PaddTb.OnDisabledState = stateProperties34;
            stateProperties35.BorderColor = Color.FromArgb(105, 181, 255);
            stateProperties35.FillColor = Color.Empty;
            stateProperties35.ForeColor = Color.Empty;
            stateProperties35.PlaceholderForeColor = Color.Empty;
            PaddTb.OnHoverState = stateProperties35;
            stateProperties36.BorderColor = Color.Silver;
            stateProperties36.FillColor = Color.White;
            stateProperties36.ForeColor = Color.Red;
            stateProperties36.PlaceholderForeColor = Color.Empty;
            PaddTb.OnIdleState = stateProperties36;
            PaddTb.Padding = new Padding(4, 3, 4, 3);
            PaddTb.PasswordChar = '\0';
            PaddTb.PlaceholderForeColor = Color.Silver;
            PaddTb.PlaceholderText = "Enter text";
            PaddTb.ReadOnly = false;
            PaddTb.ScrollBars = ScrollBars.None;
            PaddTb.SelectedText = "";
            PaddTb.SelectionLength = 0;
            PaddTb.SelectionStart = 0;
            PaddTb.ShortcutsEnabled = true;
            PaddTb.Size = new Size(244, 41);
            PaddTb.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            PaddTb.TabIndex = 28;
            PaddTb.TextAlign = HorizontalAlignment.Left;
            PaddTb.TextMarginBottom = 0;
            PaddTb.TextMarginLeft = 3;
            PaddTb.TextMarginTop = 1;
            PaddTb.TextPlaceholder = "Enter text";
            PaddTb.UseSystemPasswordChar = false;
            PaddTb.WordWrap = true;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.Navy;
            label8.Location = new Point(90, 261);
            label8.Margin = new Padding(4, 0, 4, 0);
            label8.Name = "label8";
            label8.Size = new Size(115, 23);
            label8.TabIndex = 29;
            label8.Text = "Nationality";
            // 
            // natcb
            // 
            natcb.Font = new Font("Century Gothic", 12F);
            natcb.ForeColor = Color.Red;
            natcb.FormattingEnabled = true;
            natcb.Items.AddRange(new object[] { "BANGLADESHI", "INDIAN", "PAKISTANI", "PALESTANIAN", "AMERICAN", "GERMAN", "CONGOLESE", "FINISH", "NIGERIAN", "SPANISH", "TURKISH" });
            natcb.Location = new Point(253, 252);
            natcb.Margin = new Padding(4, 3, 4, 3);
            natcb.Name = "natcb";
            natcb.Size = new Size(242, 31);
            natcb.TabIndex = 30;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.Navy;
            label9.Location = new Point(567, 261);
            label9.Margin = new Padding(4, 0, 4, 0);
            label9.Name = "label9";
            label9.Size = new Size(84, 23);
            label9.TabIndex = 31;
            label9.Text = "Gender";
            // 
            // GendCb
            // 
            GendCb.Font = new Font("Century Gothic", 12F);
            GendCb.ForeColor = Color.Red;
            GendCb.FormattingEnabled = true;
            GendCb.Items.AddRange(new object[] { "MALE", "FEMALE" });
            GendCb.Location = new Point(690, 252);
            GendCb.Margin = new Padding(4, 3, 4, 3);
            GendCb.Name = "GendCb";
            GendCb.Size = new Size(242, 31);
            GendCb.TabIndex = 32;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.Navy;
            label10.Location = new Point(345, 312);
            label10.Margin = new Padding(4, 0, 4, 0);
            label10.Name = "label10";
            label10.Size = new Size(71, 23);
            label10.TabIndex = 33;
            label10.Text = "Phone";
            // 
            // PphoneTb
            // 
            PphoneTb.AcceptsReturn = false;
            PphoneTb.AcceptsTab = false;
            PphoneTb.AnimationSpeed = 200;
            PphoneTb.AutoCompleteMode = AutoCompleteMode.None;
            PphoneTb.AutoCompleteSource = AutoCompleteSource.None;
            PphoneTb.AutoSizeHeight = true;
            PphoneTb.BackColor = Color.White;
            PphoneTb.BackgroundImage = (Image)resources.GetObject("PphoneTb.BackgroundImage");
            PphoneTb.BorderColorActive = Color.DodgerBlue;
            PphoneTb.BorderColorDisabled = Color.FromArgb(204, 204, 204);
            PphoneTb.BorderColorHover = Color.FromArgb(105, 181, 255);
            PphoneTb.BorderColorIdle = Color.Silver;
            PphoneTb.BorderRadius = 1;
            PphoneTb.BorderThickness = 1;
            PphoneTb.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            PphoneTb.CharacterCasing = CharacterCasing.Normal;
            PphoneTb.Cursor = Cursors.IBeam;
            PphoneTb.DefaultFont = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            PphoneTb.DefaultText = "";
            PphoneTb.FillColor = Color.White;
            PphoneTb.ForeColor = Color.Red;
            PphoneTb.HideSelection = true;
            PphoneTb.IconLeft = null;
            PphoneTb.IconLeftCursor = Cursors.IBeam;
            PphoneTb.IconPadding = 10;
            PphoneTb.IconRight = null;
            PphoneTb.IconRightCursor = Cursors.IBeam;
            PphoneTb.Location = new Point(466, 303);
            PphoneTb.Margin = new Padding(4, 3, 4, 3);
            PphoneTb.MaxLength = 32767;
            PphoneTb.MinimumSize = new Size(2, 1);
            PphoneTb.Modified = false;
            PphoneTb.Multiline = false;
            PphoneTb.Name = "PphoneTb";
            stateProperties37.BorderColor = Color.DodgerBlue;
            stateProperties37.FillColor = Color.Empty;
            stateProperties37.ForeColor = Color.Empty;
            stateProperties37.PlaceholderForeColor = Color.Empty;
            PphoneTb.OnActiveState = stateProperties37;
            stateProperties38.BorderColor = Color.FromArgb(204, 204, 204);
            stateProperties38.FillColor = Color.FromArgb(240, 240, 240);
            stateProperties38.ForeColor = Color.FromArgb(109, 109, 109);
            stateProperties38.PlaceholderForeColor = Color.DarkGray;
            PphoneTb.OnDisabledState = stateProperties38;
            stateProperties39.BorderColor = Color.FromArgb(105, 181, 255);
            stateProperties39.FillColor = Color.Empty;
            stateProperties39.ForeColor = Color.Empty;
            stateProperties39.PlaceholderForeColor = Color.Empty;
            PphoneTb.OnHoverState = stateProperties39;
            stateProperties40.BorderColor = Color.Silver;
            stateProperties40.FillColor = Color.White;
            stateProperties40.ForeColor = Color.Red;
            stateProperties40.PlaceholderForeColor = Color.Empty;
            PphoneTb.OnIdleState = stateProperties40;
            PphoneTb.Padding = new Padding(4, 3, 4, 3);
            PphoneTb.PasswordChar = '\0';
            PphoneTb.PlaceholderForeColor = Color.Silver;
            PphoneTb.PlaceholderText = "Enter text";
            PphoneTb.ReadOnly = false;
            PphoneTb.ScrollBars = ScrollBars.None;
            PphoneTb.SelectedText = "";
            PphoneTb.SelectionLength = 0;
            PphoneTb.SelectionStart = 0;
            PphoneTb.ShortcutsEnabled = true;
            PphoneTb.Size = new Size(244, 41);
            PphoneTb.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            PphoneTb.TabIndex = 34;
            PphoneTb.TextAlign = HorizontalAlignment.Left;
            PphoneTb.TextMarginBottom = 0;
            PphoneTb.TextMarginLeft = 3;
            PphoneTb.TextMarginTop = 1;
            PphoneTb.TextPlaceholder = "Enter text";
            PphoneTb.UseSystemPasswordChar = false;
            PphoneTb.WordWrap = true;
            // 
            // button4
            // 
            button4.BackColor = Color.Navy;
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button4.ForeColor = Color.White;
            button4.Location = new Point(690, 374);
            button4.Margin = new Padding(4, 3, 4, 3);
            button4.Name = "button4";
            button4.Size = new Size(141, 37);
            button4.TabIndex = 39;
            button4.Text = "Back";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.Navy;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.ForeColor = Color.White;
            button3.Location = new Point(328, 374);
            button3.Margin = new Padding(4, 3, 4, 3);
            button3.Name = "button3";
            button3.Size = new Size(141, 37);
            button3.TabIndex = 38;
            button3.Text = "Delete";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.Navy;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.White;
            button2.Location = new Point(510, 374);
            button2.Margin = new Padding(4, 3, 4, 3);
            button2.Name = "button2";
            button2.Size = new Size(141, 37);
            button2.TabIndex = 37;
            button2.Text = "Reset";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.Navy;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.White;
            button1.Location = new Point(150, 374);
            button1.Margin = new Padding(4, 3, 4, 3);
            button1.Name = "button1";
            button1.Size = new Size(141, 37);
            button1.TabIndex = 36;
            button1.Text = "Update";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // PassengerDGV
            // 
            dataGridViewCellStyle4.BackColor = Color.White;
            PassengerDGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = Color.FromArgb(100, 88, 255);
            dataGridViewCellStyle5.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle5.ForeColor = Color.White;
            dataGridViewCellStyle5.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = DataGridViewTriState.True;
            PassengerDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            PassengerDGV.ColumnHeadersHeight = 30;
            PassengerDGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = Color.White;
            dataGridViewCellStyle6.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle6.ForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle6.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dataGridViewCellStyle6.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle6.WrapMode = DataGridViewTriState.False;
            PassengerDGV.DefaultCellStyle = dataGridViewCellStyle6;
            PassengerDGV.GridColor = Color.FromArgb(231, 229, 255);
            PassengerDGV.Location = new Point(6, 417);
            PassengerDGV.Margin = new Padding(4, 3, 4, 3);
            PassengerDGV.Name = "PassengerDGV";
            PassengerDGV.RowHeadersVisible = false;
            PassengerDGV.RowHeadersWidth = 51;
            PassengerDGV.Size = new Size(987, 245);
            PassengerDGV.TabIndex = 40;
            PassengerDGV.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            PassengerDGV.ThemeStyle.AlternatingRowsStyle.Font = null;
            PassengerDGV.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            PassengerDGV.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            PassengerDGV.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            PassengerDGV.ThemeStyle.BackColor = Color.White;
            PassengerDGV.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            PassengerDGV.ThemeStyle.HeaderStyle.BackColor = Color.Navy;
            PassengerDGV.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            PassengerDGV.ThemeStyle.HeaderStyle.Font = new Font("Century Gothic", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            PassengerDGV.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            PassengerDGV.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            PassengerDGV.ThemeStyle.HeaderStyle.Height = 30;
            PassengerDGV.ThemeStyle.ReadOnly = false;
            PassengerDGV.ThemeStyle.RowsStyle.BackColor = Color.White;
            PassengerDGV.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            PassengerDGV.ThemeStyle.RowsStyle.Font = new Font("Century Gothic", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            PassengerDGV.ThemeStyle.RowsStyle.ForeColor = Color.FromArgb(71, 69, 94);
            PassengerDGV.ThemeStyle.RowsStyle.Height = 29;
            PassengerDGV.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            PassengerDGV.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            PassengerDGV.CellContentClick += PassengerDGV_CellContentClick;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Navy;
            panel1.Controls.Add(panel2);
            panel1.Dock = DockStyle.Bottom;
            panel1.Location = new Point(0, 687);
            panel1.Margin = new Padding(4, 3, 4, 3);
            panel1.Name = "panel1";
            panel1.Size = new Size(993, 18);
            panel1.TabIndex = 41;
            // 
            // panel2
            // 
            panel2.Location = new Point(0, 0);
            panel2.Margin = new Padding(4, 3, 4, 3);
            panel2.Name = "panel2";
            panel2.Size = new Size(375, 144);
            panel2.TabIndex = 0;
            // 
            // panel3
            // 
            panel3.BackColor = Color.Crimson;
            panel3.Controls.Add(label4);
            panel3.Dock = DockStyle.Top;
            panel3.Location = new Point(0, 0);
            panel3.Margin = new Padding(4, 3, 4, 3);
            panel3.Name = "panel3";
            panel3.Size = new Size(993, 29);
            panel3.TabIndex = 42;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.White;
            label4.Font = new Font("Century Gothic", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.Red;
            label4.Location = new Point(965, 2);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(28, 27);
            label4.TabIndex = 37;
            label4.Text = "X";
            label4.Click += label4_Click;
            // 
            // ViewPassenger
            // 
            AutoScaleDimensions = new SizeF(12F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(993, 705);
            Controls.Add(panel3);
            Controls.Add(panel1);
            Controls.Add(PassengerDGV);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(PphoneTb);
            Controls.Add(label10);
            Controls.Add(GendCb);
            Controls.Add(label9);
            Controls.Add(natcb);
            Controls.Add(label8);
            Controls.Add(PaddTb);
            Controls.Add(label7);
            Controls.Add(PnameTb);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(PpassTb);
            Controls.Add(label3);
            Controls.Add(PidTb);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Century Gothic", 12F);
            ForeColor = Color.Red;
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4, 3, 4, 3);
            Name = "ViewPassenger";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ViewPassenger";
            Load += ViewPassenger_Load;
            ((System.ComponentModel.ISupportInitialize)PassengerDGV).EndInit();
            panel1.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label2;
        private Label label1;
        private Label label6;
        private Label label5;
        private Bunifu.UI.WinForms.BunifuTextBox PpassTb;
        private Label label3;
        private Bunifu.UI.WinForms.BunifuTextBox PidTb;
        private Label label7;
        private Bunifu.UI.WinForms.BunifuTextBox PnameTb;
        private Bunifu.UI.WinForms.BunifuTextBox PaddTb;
        private Label label8;
        private ComboBox natcb;
        private Label label9;
        private ComboBox GendCb;
        private Label label10;
        private Bunifu.UI.WinForms.BunifuTextBox PphoneTb;
        private Button button4;
        private Button button3;
        private Button button2;
        private Button button1;
        private Guna.UI2.WinForms.Guna2DataGridView PassengerDGV;
        private Panel panel1;
        private Panel panel2;
        private Panel panel3;
        private Label label4;
    }
}