﻿namespace Airline_Management_System
{
    partial class CancellationTbl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CancellationTbl));
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            CancelDGV = new Guna.UI2.WinForms.Guna2DataGridView();
            label12 = new Label();
            label6 = new Label();
            label5 = new Label();
            TidCb = new ComboBox();
            label4 = new Label();
            label3 = new Label();
            CanId = new Bunifu.UI.WinForms.BunifuTextBox();
            label10 = new Label();
            label2 = new Label();
            label1 = new Label();
            button4 = new Button();
            button2 = new Button();
            button1 = new Button();
            FcodeTb = new Bunifu.UI.WinForms.BunifuTextBox();
            CancDate = new DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)CancelDGV).BeginInit();
            SuspendLayout();
            // 
            // CancelDGV
            // 
            dataGridViewCellStyle1.BackColor = Color.White;
            CancelDGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(100, 88, 255);
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            CancelDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            CancelDGV.ColumnHeadersHeight = 4;
            CancelDGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.White;
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle3.ForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dataGridViewCellStyle3.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            CancelDGV.DefaultCellStyle = dataGridViewCellStyle3;
            CancelDGV.GridColor = Color.FromArgb(231, 229, 255);
            CancelDGV.Location = new Point(67, 372);
            CancelDGV.Name = "CancelDGV";
            CancelDGV.RowHeadersVisible = false;
            CancelDGV.RowHeadersWidth = 51;
            CancelDGV.Size = new Size(905, 261);
            CancelDGV.TabIndex = 68;
            CancelDGV.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            CancelDGV.ThemeStyle.AlternatingRowsStyle.Font = null;
            CancelDGV.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            CancelDGV.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            CancelDGV.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            CancelDGV.ThemeStyle.BackColor = Color.White;
            CancelDGV.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            CancelDGV.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            CancelDGV.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            CancelDGV.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 9F);
            CancelDGV.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            CancelDGV.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            CancelDGV.ThemeStyle.HeaderStyle.Height = 4;
            CancelDGV.ThemeStyle.ReadOnly = false;
            CancelDGV.ThemeStyle.RowsStyle.BackColor = Color.White;
            CancelDGV.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            CancelDGV.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 9F);
            CancelDGV.ThemeStyle.RowsStyle.ForeColor = Color.FromArgb(71, 69, 94);
            CancelDGV.ThemeStyle.RowsStyle.Height = 29;
            CancelDGV.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            CancelDGV.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            CancelDGV.CellContentClick += guna2DataGridView1_CellContentClick;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Century Gothic", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label12.ForeColor = Color.Red;
            label12.Location = new Point(401, 330);
            label12.Name = "label12";
            label12.Size = new Size(207, 27);
            label12.TabIndex = 67;
            label12.Text = "Cancellations List";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.Navy;
            label6.Location = new Point(510, 210);
            label6.Name = "label6";
            label6.Size = new Size(56, 23);
            label6.TabIndex = 58;
            label6.Text = "Date";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.Navy;
            label5.Location = new Point(210, 205);
            label5.Name = "label5";
            label5.Size = new Size(116, 23);
            label5.TabIndex = 55;
            label5.Text = "FlightCode";
            // 
            // TidCb
            // 
            TidCb.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            TidCb.ForeColor = Color.Red;
            TidCb.FormattingEnabled = true;
            TidCb.Location = new Point(628, 147);
            TidCb.Name = "TidCb";
            TidCb.Size = new Size(146, 31);
            TidCb.TabIndex = 54;
            TidCb.SelectionChangeCommitted += TidCb_SelectionChangeCommitted;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.Navy;
            label4.Location = new Point(510, 150);
            label4.Name = "label4";
            label4.Size = new Size(87, 23);
            label4.TabIndex = 53;
            label4.Text = "TicketID";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Navy;
            label3.Location = new Point(210, 150);
            label3.Name = "label3";
            label3.Size = new Size(102, 23);
            label3.TabIndex = 52;
            label3.Text = "CancelID";
            // 
            // CanId
            // 
            CanId.AcceptsReturn = false;
            CanId.AcceptsTab = false;
            CanId.AnimationSpeed = 200;
            CanId.AutoCompleteMode = AutoCompleteMode.None;
            CanId.AutoCompleteSource = AutoCompleteSource.None;
            CanId.AutoSizeHeight = true;
            CanId.BackColor = Color.White;
            CanId.BackgroundImage = (Image)resources.GetObject("CanId.BackgroundImage");
            CanId.BorderColorActive = Color.DodgerBlue;
            CanId.BorderColorDisabled = Color.FromArgb(204, 204, 204);
            CanId.BorderColorHover = Color.FromArgb(105, 181, 255);
            CanId.BorderColorIdle = Color.Silver;
            CanId.BorderRadius = 1;
            CanId.BorderThickness = 1;
            CanId.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            CanId.CharacterCasing = CharacterCasing.Normal;
            CanId.Cursor = Cursors.IBeam;
            CanId.DefaultFont = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CanId.DefaultText = "";
            CanId.FillColor = Color.White;
            CanId.ForeColor = Color.Red;
            CanId.HideSelection = true;
            CanId.IconLeft = null;
            CanId.IconLeftCursor = Cursors.IBeam;
            CanId.IconPadding = 10;
            CanId.IconRight = null;
            CanId.IconRightCursor = Cursors.IBeam;
            CanId.Location = new Point(350, 147);
            CanId.MaxLength = 32767;
            CanId.MinimumSize = new Size(1, 1);
            CanId.Modified = false;
            CanId.Multiline = false;
            CanId.Name = "CanId";
            stateProperties1.BorderColor = Color.DodgerBlue;
            stateProperties1.FillColor = Color.Empty;
            stateProperties1.ForeColor = Color.Empty;
            stateProperties1.PlaceholderForeColor = Color.Empty;
            CanId.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = Color.FromArgb(204, 204, 204);
            stateProperties2.FillColor = Color.FromArgb(240, 240, 240);
            stateProperties2.ForeColor = Color.FromArgb(109, 109, 109);
            stateProperties2.PlaceholderForeColor = Color.DarkGray;
            CanId.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = Color.FromArgb(105, 181, 255);
            stateProperties3.FillColor = Color.Empty;
            stateProperties3.ForeColor = Color.Empty;
            stateProperties3.PlaceholderForeColor = Color.Empty;
            CanId.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = Color.Silver;
            stateProperties4.FillColor = Color.White;
            stateProperties4.ForeColor = Color.Red;
            stateProperties4.PlaceholderForeColor = Color.Empty;
            CanId.OnIdleState = stateProperties4;
            CanId.Padding = new Padding(3);
            CanId.PasswordChar = '\0';
            CanId.PlaceholderForeColor = Color.Silver;
            CanId.PlaceholderText = "Enter text";
            CanId.ReadOnly = false;
            CanId.ScrollBars = ScrollBars.None;
            CanId.SelectedText = "";
            CanId.SelectionLength = 0;
            CanId.SelectionStart = 0;
            CanId.ShortcutsEnabled = true;
            CanId.Size = new Size(134, 33);
            CanId.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            CanId.TabIndex = 51;
            CanId.TextAlign = HorizontalAlignment.Left;
            CanId.TextMarginBottom = 0;
            CanId.TextMarginLeft = 3;
            CanId.TextMarginTop = 1;
            CanId.TextPlaceholder = "Enter text";
            CanId.UseSystemPasswordChar = false;
            CanId.WordWrap = true;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Century Gothic", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.Red;
            label10.Location = new Point(979, 9);
            label10.Name = "label10";
            label10.Size = new Size(28, 27);
            label10.TabIndex = 50;
            label10.Text = "X";
            label10.Click += label10_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Century Gothic", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Red;
            label2.Location = new Point(343, 82);
            label2.Name = "label2";
            label2.Size = new Size(277, 34);
            label2.TabIndex = 49;
            label2.Text = "Ticket Cancellation";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Red;
            label1.Location = new Point(293, 48);
            label1.Name = "label1";
            label1.Size = new Size(372, 34);
            label1.TabIndex = 48;
            label1.Text = "Biman Bangladesh Airlines";
            // 
            // button4
            // 
            button4.BackColor = Color.Navy;
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button4.ForeColor = Color.White;
            button4.Location = new Point(680, 267);
            button4.Margin = new Padding(6, 4, 6, 4);
            button4.Name = "button4";
            button4.Size = new Size(212, 42);
            button4.TabIndex = 71;
            button4.Text = "Back";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.Navy;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.White;
            button2.Location = new Point(408, 267);
            button2.Margin = new Padding(6, 4, 6, 4);
            button2.Name = "button2";
            button2.Size = new Size(212, 42);
            button2.TabIndex = 70;
            button2.Text = "Clear";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.Navy;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.White;
            button1.Location = new Point(109, 267);
            button1.Margin = new Padding(6, 4, 6, 4);
            button1.Name = "button1";
            button1.Size = new Size(212, 42);
            button1.TabIndex = 69;
            button1.Text = "Cancel";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // FcodeTb
            // 
            FcodeTb.AcceptsReturn = false;
            FcodeTb.AcceptsTab = false;
            FcodeTb.AnimationSpeed = 200;
            FcodeTb.AutoCompleteMode = AutoCompleteMode.None;
            FcodeTb.AutoCompleteSource = AutoCompleteSource.None;
            FcodeTb.AutoSizeHeight = true;
            FcodeTb.BackColor = Color.White;
            FcodeTb.BackgroundImage = (Image)resources.GetObject("FcodeTb.BackgroundImage");
            FcodeTb.BorderColorActive = Color.DodgerBlue;
            FcodeTb.BorderColorDisabled = Color.FromArgb(204, 204, 204);
            FcodeTb.BorderColorHover = Color.FromArgb(105, 181, 255);
            FcodeTb.BorderColorIdle = Color.Silver;
            FcodeTb.BorderRadius = 1;
            FcodeTb.BorderThickness = 1;
            FcodeTb.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            FcodeTb.CharacterCasing = CharacterCasing.Normal;
            FcodeTb.Cursor = Cursors.IBeam;
            FcodeTb.DefaultFont = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            FcodeTb.DefaultText = "";
            FcodeTb.Enabled = false;
            FcodeTb.FillColor = Color.White;
            FcodeTb.ForeColor = Color.Red;
            FcodeTb.HideSelection = true;
            FcodeTb.IconLeft = null;
            FcodeTb.IconLeftCursor = Cursors.IBeam;
            FcodeTb.IconPadding = 10;
            FcodeTb.IconRight = null;
            FcodeTb.IconRightCursor = Cursors.IBeam;
            FcodeTb.Location = new Point(350, 200);
            FcodeTb.MaxLength = 32767;
            FcodeTb.MinimumSize = new Size(1, 1);
            FcodeTb.Modified = false;
            FcodeTb.Multiline = false;
            FcodeTb.Name = "FcodeTb";
            stateProperties5.BorderColor = Color.DodgerBlue;
            stateProperties5.FillColor = Color.Empty;
            stateProperties5.ForeColor = Color.Empty;
            stateProperties5.PlaceholderForeColor = Color.Empty;
            FcodeTb.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = Color.FromArgb(204, 204, 204);
            stateProperties6.FillColor = Color.FromArgb(240, 240, 240);
            stateProperties6.ForeColor = Color.FromArgb(109, 109, 109);
            stateProperties6.PlaceholderForeColor = Color.DarkGray;
            FcodeTb.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = Color.FromArgb(105, 181, 255);
            stateProperties7.FillColor = Color.Empty;
            stateProperties7.ForeColor = Color.Empty;
            stateProperties7.PlaceholderForeColor = Color.Empty;
            FcodeTb.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = Color.Silver;
            stateProperties8.FillColor = Color.White;
            stateProperties8.ForeColor = Color.Red;
            stateProperties8.PlaceholderForeColor = Color.Empty;
            FcodeTb.OnIdleState = stateProperties8;
            FcodeTb.Padding = new Padding(3);
            FcodeTb.PasswordChar = '\0';
            FcodeTb.PlaceholderForeColor = Color.Silver;
            FcodeTb.PlaceholderText = "Enter text";
            FcodeTb.ReadOnly = false;
            FcodeTb.ScrollBars = ScrollBars.None;
            FcodeTb.SelectedText = "";
            FcodeTb.SelectionLength = 0;
            FcodeTb.SelectionStart = 0;
            FcodeTb.ShortcutsEnabled = true;
            FcodeTb.Size = new Size(134, 33);
            FcodeTb.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material;
            FcodeTb.TabIndex = 72;
            FcodeTb.TextAlign = HorizontalAlignment.Right;
            FcodeTb.TextMarginBottom = 0;
            FcodeTb.TextMarginLeft = 3;
            FcodeTb.TextMarginTop = 1;
            FcodeTb.TextPlaceholder = "Enter text";
            FcodeTb.UseSystemPasswordChar = false;
            FcodeTb.WordWrap = true;
            // 
            // CancDate
            // 
            CancDate.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            CancDate.Location = new Point(628, 205);
            CancDate.Name = "CancDate";
            CancDate.Size = new Size(146, 32);
            CancDate.TabIndex = 73;
            // 
            // CancellationTbl
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1019, 658);
            Controls.Add(CancDate);
            Controls.Add(FcodeTb);
            Controls.Add(button4);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(CancelDGV);
            Controls.Add(label12);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(TidCb);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(CanId);
            Controls.Add(label10);
            Controls.Add(label2);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "CancellationTbl";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "CancellationTbl";
            Load += CancellationTbl_Load;
            ((System.ComponentModel.ISupportInitialize)CancelDGV).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Guna.UI2.WinForms.Guna2DataGridView CancelDGV;
        private Label label12;
        private Label label6;
        private Label label5;
        private ComboBox TidCb;
        private Label label4;
        private Label label3;
        private Bunifu.UI.WinForms.BunifuTextBox CanId;
        private Label label10;
        private Label label2;
        private Label label1;
        private Button button4;
        private Button button2;
        private Button button1;
        private Bunifu.UI.WinForms.BunifuTextBox FcodeTb;
        private DateTimePicker CancDate;
    }
}