﻿namespace Airline_Management_System
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges3 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges4 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            panel1 = new Panel();
            label3 = new Label();
            label1 = new Label();
            label2 = new Label();
            bunifuButton24 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            pictureBox1 = new PictureBox();
            bunifuButton21 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            bunifuButton23 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            bunifuButton22 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.Red;
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(981, 90);
            panel1.TabIndex = 0;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Century Gothic", 22.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(937, 0);
            label3.Name = "label3";
            label3.Size = new Size(44, 44);
            label3.TabIndex = 3;
            label3.Text = "X";
            label3.Click += label3_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 22.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(236, 20);
            label1.Name = "label1";
            label1.Size = new Size(488, 44);
            label1.TabIndex = 2;
            label1.Text = "Biman Bangladesh Airlines";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Century Gothic", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Red;
            label2.Location = new Point(326, 336);
            label2.Name = "label2";
            label2.Size = new Size(316, 37);
            label2.TabIndex = 3;
            label2.Text = "Your Home In The Air";
            // 
            // bunifuButton24
            // 
            bunifuButton24.AllowAnimations = true;
            bunifuButton24.AllowMouseEffects = true;
            bunifuButton24.AllowToggling = false;
            bunifuButton24.AnimationSpeed = 200;
            bunifuButton24.AutoGenerateColors = false;
            bunifuButton24.AutoRoundBorders = false;
            bunifuButton24.AutoSizeLeftIcon = true;
            bunifuButton24.AutoSizeRightIcon = true;
            bunifuButton24.BackColor = Color.Transparent;
            bunifuButton24.BackColor1 = Color.Red;
            bunifuButton24.BackgroundImage = (Image)resources.GetObject("bunifuButton24.BackgroundImage");
            bunifuButton24.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            bunifuButton24.ButtonText = "Cancellations";
            bunifuButton24.ButtonTextMarginLeft = 0;
            bunifuButton24.ColorContrastOnClick = 45;
            bunifuButton24.ColorContrastOnHover = 45;
            borderEdges1.BottomLeft = true;
            borderEdges1.BottomRight = true;
            borderEdges1.TopLeft = true;
            borderEdges1.TopRight = true;
            bunifuButton24.CustomizableEdges = borderEdges1;
            bunifuButton24.DialogResult = DialogResult.None;
            bunifuButton24.DisabledBorderColor = Color.FromArgb(191, 191, 191);
            bunifuButton24.DisabledFillColor = Color.FromArgb(204, 204, 204);
            bunifuButton24.DisabledForecolor = Color.FromArgb(168, 160, 168);
            bunifuButton24.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            bunifuButton24.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            bunifuButton24.ForeColor = Color.White;
            bunifuButton24.IconLeftAlign = ContentAlignment.MiddleLeft;
            bunifuButton24.IconLeftCursor = Cursors.Default;
            bunifuButton24.IconLeftPadding = new Padding(11, 3, 3, 3);
            bunifuButton24.IconMarginLeft = 11;
            bunifuButton24.IconPadding = 10;
            bunifuButton24.IconRightAlign = ContentAlignment.MiddleRight;
            bunifuButton24.IconRightCursor = Cursors.Default;
            bunifuButton24.IconRightPadding = new Padding(3, 3, 7, 3);
            bunifuButton24.IconSize = 25;
            bunifuButton24.IdleBorderColor = Color.Red;
            bunifuButton24.IdleBorderRadius = 1;
            bunifuButton24.IdleBorderThickness = 1;
            bunifuButton24.IdleFillColor = Color.Red;
            bunifuButton24.IdleIconLeftImage = null;
            bunifuButton24.IdleIconRightImage = null;
            bunifuButton24.IndicateFocus = false;
            bunifuButton24.Location = new Point(767, 458);
            bunifuButton24.Name = "bunifuButton24";
            bunifuButton24.OnDisabledState.BorderColor = Color.FromArgb(191, 191, 191);
            bunifuButton24.OnDisabledState.BorderRadius = 1;
            bunifuButton24.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            bunifuButton24.OnDisabledState.BorderThickness = 1;
            bunifuButton24.OnDisabledState.FillColor = Color.FromArgb(204, 204, 204);
            bunifuButton24.OnDisabledState.ForeColor = Color.FromArgb(168, 160, 168);
            bunifuButton24.OnDisabledState.IconLeftImage = null;
            bunifuButton24.OnDisabledState.IconRightImage = null;
            bunifuButton24.onHoverState.BorderColor = Color.FromArgb(105, 181, 255);
            bunifuButton24.onHoverState.BorderRadius = 1;
            bunifuButton24.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            bunifuButton24.onHoverState.BorderThickness = 1;
            bunifuButton24.onHoverState.FillColor = Color.FromArgb(105, 181, 255);
            bunifuButton24.onHoverState.ForeColor = Color.White;
            bunifuButton24.onHoverState.IconLeftImage = null;
            bunifuButton24.onHoverState.IconRightImage = null;
            bunifuButton24.OnIdleState.BorderColor = Color.Red;
            bunifuButton24.OnIdleState.BorderRadius = 1;
            bunifuButton24.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            bunifuButton24.OnIdleState.BorderThickness = 1;
            bunifuButton24.OnIdleState.FillColor = Color.Red;
            bunifuButton24.OnIdleState.ForeColor = Color.White;
            bunifuButton24.OnIdleState.IconLeftImage = null;
            bunifuButton24.OnIdleState.IconRightImage = null;
            bunifuButton24.OnPressedState.BorderColor = Color.FromArgb(40, 96, 144);
            bunifuButton24.OnPressedState.BorderRadius = 1;
            bunifuButton24.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            bunifuButton24.OnPressedState.BorderThickness = 1;
            bunifuButton24.OnPressedState.FillColor = Color.FromArgb(40, 96, 144);
            bunifuButton24.OnPressedState.ForeColor = Color.White;
            bunifuButton24.OnPressedState.IconLeftImage = null;
            bunifuButton24.OnPressedState.IconRightImage = null;
            bunifuButton24.Size = new Size(156, 49);
            bunifuButton24.TabIndex = 7;
            bunifuButton24.TextAlign = ContentAlignment.MiddleCenter;
            bunifuButton24.TextAlignment = HorizontalAlignment.Center;
            bunifuButton24.TextMarginLeft = 0;
            bunifuButton24.TextPadding = new Padding(0);
            bunifuButton24.UseDefaultRadiusAndThickness = true;
            bunifuButton24.Click += bunifuButton24_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(363, 181);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(228, 152);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            // 
            // bunifuButton21
            // 
            bunifuButton21.AllowAnimations = true;
            bunifuButton21.AllowMouseEffects = true;
            bunifuButton21.AllowToggling = false;
            bunifuButton21.AnimationSpeed = 200;
            bunifuButton21.AutoGenerateColors = false;
            bunifuButton21.AutoRoundBorders = false;
            bunifuButton21.AutoSizeLeftIcon = true;
            bunifuButton21.AutoSizeRightIcon = true;
            bunifuButton21.BackColor = Color.Transparent;
            bunifuButton21.BackColor1 = Color.Red;
            bunifuButton21.BackgroundImage = (Image)resources.GetObject("bunifuButton21.BackgroundImage");
            bunifuButton21.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            bunifuButton21.ButtonText = "Flights";
            bunifuButton21.ButtonTextMarginLeft = 0;
            bunifuButton21.ColorContrastOnClick = 45;
            bunifuButton21.ColorContrastOnHover = 45;
            borderEdges2.BottomLeft = true;
            borderEdges2.BottomRight = true;
            borderEdges2.TopLeft = true;
            borderEdges2.TopRight = true;
            bunifuButton21.CustomizableEdges = borderEdges2;
            bunifuButton21.DialogResult = DialogResult.None;
            bunifuButton21.DisabledBorderColor = Color.FromArgb(191, 191, 191);
            bunifuButton21.DisabledFillColor = Color.FromArgb(204, 204, 204);
            bunifuButton21.DisabledForecolor = Color.FromArgb(168, 160, 168);
            bunifuButton21.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            bunifuButton21.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            bunifuButton21.ForeColor = Color.White;
            bunifuButton21.IconLeftAlign = ContentAlignment.MiddleLeft;
            bunifuButton21.IconLeftCursor = Cursors.Default;
            bunifuButton21.IconLeftPadding = new Padding(11, 3, 3, 3);
            bunifuButton21.IconMarginLeft = 11;
            bunifuButton21.IconPadding = 10;
            bunifuButton21.IconRightAlign = ContentAlignment.MiddleRight;
            bunifuButton21.IconRightCursor = Cursors.Default;
            bunifuButton21.IconRightPadding = new Padding(3, 3, 7, 3);
            bunifuButton21.IconSize = 25;
            bunifuButton21.IdleBorderColor = Color.Red;
            bunifuButton21.IdleBorderRadius = 1;
            bunifuButton21.IdleBorderThickness = 1;
            bunifuButton21.IdleFillColor = Color.Red;
            bunifuButton21.IdleIconLeftImage = null;
            bunifuButton21.IdleIconRightImage = null;
            bunifuButton21.IndicateFocus = false;
            bunifuButton21.Location = new Point(83, 458);
            bunifuButton21.Name = "bunifuButton21";
            bunifuButton21.OnDisabledState.BorderColor = Color.FromArgb(191, 191, 191);
            bunifuButton21.OnDisabledState.BorderRadius = 1;
            bunifuButton21.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            bunifuButton21.OnDisabledState.BorderThickness = 1;
            bunifuButton21.OnDisabledState.FillColor = Color.FromArgb(204, 204, 204);
            bunifuButton21.OnDisabledState.ForeColor = Color.FromArgb(168, 160, 168);
            bunifuButton21.OnDisabledState.IconLeftImage = null;
            bunifuButton21.OnDisabledState.IconRightImage = null;
            bunifuButton21.onHoverState.BorderColor = Color.FromArgb(105, 181, 255);
            bunifuButton21.onHoverState.BorderRadius = 1;
            bunifuButton21.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            bunifuButton21.onHoverState.BorderThickness = 1;
            bunifuButton21.onHoverState.FillColor = Color.FromArgb(105, 181, 255);
            bunifuButton21.onHoverState.ForeColor = Color.White;
            bunifuButton21.onHoverState.IconLeftImage = null;
            bunifuButton21.onHoverState.IconRightImage = null;
            bunifuButton21.OnIdleState.BorderColor = Color.Red;
            bunifuButton21.OnIdleState.BorderRadius = 1;
            bunifuButton21.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            bunifuButton21.OnIdleState.BorderThickness = 1;
            bunifuButton21.OnIdleState.FillColor = Color.Red;
            bunifuButton21.OnIdleState.ForeColor = Color.White;
            bunifuButton21.OnIdleState.IconLeftImage = null;
            bunifuButton21.OnIdleState.IconRightImage = null;
            bunifuButton21.OnPressedState.BorderColor = Color.FromArgb(40, 96, 144);
            bunifuButton21.OnPressedState.BorderRadius = 1;
            bunifuButton21.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            bunifuButton21.OnPressedState.BorderThickness = 1;
            bunifuButton21.OnPressedState.FillColor = Color.FromArgb(40, 96, 144);
            bunifuButton21.OnPressedState.ForeColor = Color.White;
            bunifuButton21.OnPressedState.IconLeftImage = null;
            bunifuButton21.OnPressedState.IconRightImage = null;
            bunifuButton21.Size = new Size(156, 49);
            bunifuButton21.TabIndex = 9;
            bunifuButton21.TextAlign = ContentAlignment.MiddleCenter;
            bunifuButton21.TextAlignment = HorizontalAlignment.Center;
            bunifuButton21.TextMarginLeft = 0;
            bunifuButton21.TextPadding = new Padding(0);
            bunifuButton21.UseDefaultRadiusAndThickness = true;
            bunifuButton21.Click += bunifuButton21_Click_1;
            // 
            // bunifuButton23
            // 
            bunifuButton23.AllowAnimations = true;
            bunifuButton23.AllowMouseEffects = true;
            bunifuButton23.AllowToggling = false;
            bunifuButton23.AnimationSpeed = 200;
            bunifuButton23.AutoGenerateColors = false;
            bunifuButton23.AutoRoundBorders = false;
            bunifuButton23.AutoSizeLeftIcon = true;
            bunifuButton23.AutoSizeRightIcon = true;
            bunifuButton23.BackColor = Color.Transparent;
            bunifuButton23.BackColor1 = Color.Red;
            bunifuButton23.BackgroundImage = (Image)resources.GetObject("bunifuButton23.BackgroundImage");
            bunifuButton23.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            bunifuButton23.ButtonText = "Tickets";
            bunifuButton23.ButtonTextMarginLeft = 0;
            bunifuButton23.ColorContrastOnClick = 45;
            bunifuButton23.ColorContrastOnHover = 45;
            borderEdges3.BottomLeft = true;
            borderEdges3.BottomRight = true;
            borderEdges3.TopLeft = true;
            borderEdges3.TopRight = true;
            bunifuButton23.CustomizableEdges = borderEdges3;
            bunifuButton23.DialogResult = DialogResult.None;
            bunifuButton23.DisabledBorderColor = Color.FromArgb(191, 191, 191);
            bunifuButton23.DisabledFillColor = Color.FromArgb(204, 204, 204);
            bunifuButton23.DisabledForecolor = Color.FromArgb(168, 160, 168);
            bunifuButton23.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            bunifuButton23.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            bunifuButton23.ForeColor = Color.White;
            bunifuButton23.IconLeftAlign = ContentAlignment.MiddleLeft;
            bunifuButton23.IconLeftCursor = Cursors.Default;
            bunifuButton23.IconLeftPadding = new Padding(11, 3, 3, 3);
            bunifuButton23.IconMarginLeft = 11;
            bunifuButton23.IconPadding = 10;
            bunifuButton23.IconRightAlign = ContentAlignment.MiddleRight;
            bunifuButton23.IconRightCursor = Cursors.Default;
            bunifuButton23.IconRightPadding = new Padding(3, 3, 7, 3);
            bunifuButton23.IconSize = 25;
            bunifuButton23.IdleBorderColor = Color.Red;
            bunifuButton23.IdleBorderRadius = 1;
            bunifuButton23.IdleBorderThickness = 1;
            bunifuButton23.IdleFillColor = Color.Red;
            bunifuButton23.IdleIconLeftImage = null;
            bunifuButton23.IdleIconRightImage = null;
            bunifuButton23.IndicateFocus = false;
            bunifuButton23.Location = new Point(555, 458);
            bunifuButton23.Name = "bunifuButton23";
            bunifuButton23.OnDisabledState.BorderColor = Color.FromArgb(191, 191, 191);
            bunifuButton23.OnDisabledState.BorderRadius = 1;
            bunifuButton23.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            bunifuButton23.OnDisabledState.BorderThickness = 1;
            bunifuButton23.OnDisabledState.FillColor = Color.FromArgb(204, 204, 204);
            bunifuButton23.OnDisabledState.ForeColor = Color.FromArgb(168, 160, 168);
            bunifuButton23.OnDisabledState.IconLeftImage = null;
            bunifuButton23.OnDisabledState.IconRightImage = null;
            bunifuButton23.onHoverState.BorderColor = Color.FromArgb(105, 181, 255);
            bunifuButton23.onHoverState.BorderRadius = 1;
            bunifuButton23.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            bunifuButton23.onHoverState.BorderThickness = 1;
            bunifuButton23.onHoverState.FillColor = Color.FromArgb(105, 181, 255);
            bunifuButton23.onHoverState.ForeColor = Color.White;
            bunifuButton23.onHoverState.IconLeftImage = null;
            bunifuButton23.onHoverState.IconRightImage = null;
            bunifuButton23.OnIdleState.BorderColor = Color.Red;
            bunifuButton23.OnIdleState.BorderRadius = 1;
            bunifuButton23.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            bunifuButton23.OnIdleState.BorderThickness = 1;
            bunifuButton23.OnIdleState.FillColor = Color.Red;
            bunifuButton23.OnIdleState.ForeColor = Color.White;
            bunifuButton23.OnIdleState.IconLeftImage = null;
            bunifuButton23.OnIdleState.IconRightImage = null;
            bunifuButton23.OnPressedState.BorderColor = Color.FromArgb(40, 96, 144);
            bunifuButton23.OnPressedState.BorderRadius = 1;
            bunifuButton23.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            bunifuButton23.OnPressedState.BorderThickness = 1;
            bunifuButton23.OnPressedState.FillColor = Color.FromArgb(40, 96, 144);
            bunifuButton23.OnPressedState.ForeColor = Color.White;
            bunifuButton23.OnPressedState.IconLeftImage = null;
            bunifuButton23.OnPressedState.IconRightImage = null;
            bunifuButton23.Size = new Size(156, 49);
            bunifuButton23.TabIndex = 10;
            bunifuButton23.TextAlign = ContentAlignment.MiddleCenter;
            bunifuButton23.TextAlignment = HorizontalAlignment.Center;
            bunifuButton23.TextMarginLeft = 0;
            bunifuButton23.TextPadding = new Padding(0);
            bunifuButton23.UseDefaultRadiusAndThickness = true;
            bunifuButton23.Click += bunifuButton23_Click_1;
            // 
            // bunifuButton22
            // 
            bunifuButton22.AllowAnimations = true;
            bunifuButton22.AllowMouseEffects = true;
            bunifuButton22.AllowToggling = false;
            bunifuButton22.AnimationSpeed = 200;
            bunifuButton22.AutoGenerateColors = false;
            bunifuButton22.AutoRoundBorders = false;
            bunifuButton22.AutoSizeLeftIcon = true;
            bunifuButton22.AutoSizeRightIcon = true;
            bunifuButton22.BackColor = Color.Transparent;
            bunifuButton22.BackColor1 = Color.Red;
            bunifuButton22.BackgroundImage = (Image)resources.GetObject("bunifuButton22.BackgroundImage");
            bunifuButton22.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            bunifuButton22.ButtonText = "Passengers";
            bunifuButton22.ButtonTextMarginLeft = 0;
            bunifuButton22.ColorContrastOnClick = 45;
            bunifuButton22.ColorContrastOnHover = 45;
            borderEdges4.BottomLeft = true;
            borderEdges4.BottomRight = true;
            borderEdges4.TopLeft = true;
            borderEdges4.TopRight = true;
            bunifuButton22.CustomizableEdges = borderEdges4;
            bunifuButton22.DialogResult = DialogResult.None;
            bunifuButton22.DisabledBorderColor = Color.FromArgb(191, 191, 191);
            bunifuButton22.DisabledFillColor = Color.FromArgb(204, 204, 204);
            bunifuButton22.DisabledForecolor = Color.FromArgb(168, 160, 168);
            bunifuButton22.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            bunifuButton22.Font = new Font("Century Gothic", 12F, FontStyle.Bold);
            bunifuButton22.ForeColor = Color.White;
            bunifuButton22.IconLeftAlign = ContentAlignment.MiddleLeft;
            bunifuButton22.IconLeftCursor = Cursors.Default;
            bunifuButton22.IconLeftPadding = new Padding(11, 3, 3, 3);
            bunifuButton22.IconMarginLeft = 11;
            bunifuButton22.IconPadding = 10;
            bunifuButton22.IconRightAlign = ContentAlignment.MiddleRight;
            bunifuButton22.IconRightCursor = Cursors.Default;
            bunifuButton22.IconRightPadding = new Padding(3, 3, 7, 3);
            bunifuButton22.IconSize = 25;
            bunifuButton22.IdleBorderColor = Color.Red;
            bunifuButton22.IdleBorderRadius = 1;
            bunifuButton22.IdleBorderThickness = 1;
            bunifuButton22.IdleFillColor = Color.Red;
            bunifuButton22.IdleIconLeftImage = null;
            bunifuButton22.IdleIconRightImage = null;
            bunifuButton22.IndicateFocus = false;
            bunifuButton22.Location = new Point(297, 458);
            bunifuButton22.Name = "bunifuButton22";
            bunifuButton22.OnDisabledState.BorderColor = Color.FromArgb(191, 191, 191);
            bunifuButton22.OnDisabledState.BorderRadius = 1;
            bunifuButton22.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            bunifuButton22.OnDisabledState.BorderThickness = 1;
            bunifuButton22.OnDisabledState.FillColor = Color.FromArgb(204, 204, 204);
            bunifuButton22.OnDisabledState.ForeColor = Color.FromArgb(168, 160, 168);
            bunifuButton22.OnDisabledState.IconLeftImage = null;
            bunifuButton22.OnDisabledState.IconRightImage = null;
            bunifuButton22.onHoverState.BorderColor = Color.FromArgb(105, 181, 255);
            bunifuButton22.onHoverState.BorderRadius = 1;
            bunifuButton22.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            bunifuButton22.onHoverState.BorderThickness = 1;
            bunifuButton22.onHoverState.FillColor = Color.FromArgb(105, 181, 255);
            bunifuButton22.onHoverState.ForeColor = Color.White;
            bunifuButton22.onHoverState.IconLeftImage = null;
            bunifuButton22.onHoverState.IconRightImage = null;
            bunifuButton22.OnIdleState.BorderColor = Color.Red;
            bunifuButton22.OnIdleState.BorderRadius = 1;
            bunifuButton22.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            bunifuButton22.OnIdleState.BorderThickness = 1;
            bunifuButton22.OnIdleState.FillColor = Color.Red;
            bunifuButton22.OnIdleState.ForeColor = Color.White;
            bunifuButton22.OnIdleState.IconLeftImage = null;
            bunifuButton22.OnIdleState.IconRightImage = null;
            bunifuButton22.OnPressedState.BorderColor = Color.FromArgb(40, 96, 144);
            bunifuButton22.OnPressedState.BorderRadius = 1;
            bunifuButton22.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            bunifuButton22.OnPressedState.BorderThickness = 1;
            bunifuButton22.OnPressedState.FillColor = Color.FromArgb(40, 96, 144);
            bunifuButton22.OnPressedState.ForeColor = Color.White;
            bunifuButton22.OnPressedState.IconLeftImage = null;
            bunifuButton22.OnPressedState.IconRightImage = null;
            bunifuButton22.Size = new Size(188, 49);
            bunifuButton22.TabIndex = 11;
            bunifuButton22.TextAlign = ContentAlignment.MiddleCenter;
            bunifuButton22.TextAlignment = HorizontalAlignment.Center;
            bunifuButton22.TextMarginLeft = 0;
            bunifuButton22.TextPadding = new Padding(0);
            bunifuButton22.UseDefaultRadiusAndThickness = true;
            bunifuButton22.Click += bunifuButton22_Click_1;
            // 
            // Home
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(981, 539);
            Controls.Add(bunifuButton22);
            Controls.Add(bunifuButton23);
            Controls.Add(bunifuButton21);
            Controls.Add(pictureBox1);
            Controls.Add(bunifuButton24);
            Controls.Add(label2);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Home";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Home";
            Load += Home_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label1;
        private Label label2;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton24;
        private PictureBox pictureBox1;
        private Label label3;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton21;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton23;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton22;
    }
}